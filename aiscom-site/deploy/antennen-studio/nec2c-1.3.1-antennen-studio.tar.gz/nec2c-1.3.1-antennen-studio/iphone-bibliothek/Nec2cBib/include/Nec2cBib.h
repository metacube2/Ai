#ifndef NEC2CBIB_H
#define NEC2CBIB_H
/* nec2c als Bibliothek (siehe werkzeuge/nec2c_bib_erzeugen.py). Nicht threadsicher: nec2c arbeitet mit globalen Variablen,
   der Aufrufer muss Laeufe nacheinander ausfuehren (NECKern: Nec2cBibliothek). */
/* Rechnet die NEC-2-Kartendatei `ein` und schreibt die Ausgabe nach `aus`. Rueckgabe: Status wie beim Programm (0 = ok). */
int nec2c_ausfuehren(const char *ein, const char *aus);
/* Anzahl noch belegter Speicherbloecke nach dem letzten Lauf (Test: muss 0 sein) */
long nec2c_offene_bloecke(void);
/* Nur Tests: freigegebene Bloecke an spaetere Anforderungen derselben Groessenklasse zufaellig wieder vergeben (wie Androids
   Allokator), damit eine Benutzung nach Freigabe auch auf macOS auffaellt. Ausschalten gibt den Vorrat frei. */
void nec2c_test_adressen_wiederverwenden(int an, unsigned saat);
#endif
