/* Erzeugt aus Kerne/nec2c durch werkzeuge/nec2c_bib_erzeugen.py – nicht von Hand aendern. GPLv3. */
/* Fuer macOS (statt autoconf) */
#define HAVE_FCNTL_H 1
#define HAVE_FLOOR 1
#define HAVE_INTTYPES_H 1
#define HAVE_LIBM 1
#define HAVE_MALLOC 1
#define HAVE_POW 1
#define HAVE_REALLOC 1
#define HAVE_SQRT 1
#define HAVE_STDINT_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STRING_H 1
#define HAVE_UNISTD_H 1
#define PACKAGE_STRING "nec2c 1.3.1"
#define VERSION "1.3.1"
