/* Huelle fuer nec2c im Prozess der App: Rueckkehr statt exit(), Speicher je Lauf mitzaehlen und freigeben. */
#include <setjmp.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "Nec2cBib.h"
#include "shared.h"

int nec2c_main(int argc, char **argv);

static jmp_buf ruecksprung;
/* Laufnummer: statische Zwischenspeicher in nec2c (intrp) setzen sich zurueck, wenn sie sich aendert */
int nec2c_lauf = 0;
static int laeuft = 0;
static int ende_status = 0;

/* Belegte Bloecke dieses Laufs mit ihrer Groesse (einfaches Feld; nec2c belegt wenige Dutzend Bloecke je Lauf) */
static void **bloecke = NULL;
static size_t *groessen = NULL;
static long anzahl = 0, platz = 0;

/* Pruefmodus (nur Tests, nec2c_test_adressen_wiederverwenden): freigegebene Bloecke kommen in einen Vorrat und werden an
   spaetere Anforderungen derselben Groessenklasse (naechste Zweierpotenz) zufaellig wieder vergeben – so wie Androids
   Allokator (scudo) Adressen vergibt. macOS tut das im Test nicht, ohne diesen Modus bleibt eine Benutzung nach Freigabe dort
   unsichtbar. */
static int vorrat_an = 0;
static unsigned zufall = 1;
static void **vorrat = NULL;
static size_t *vorrat_groessen = NULL;
static long vorrat_anzahl = 0, vorrat_platz = 0;

static void merken(void *p, size_t n) {
    if (!p) return;
    if (n == 0) n = 1;                      /* 0 heisst bei vergessen() „nicht von diesem Lauf“ */
    if (anzahl == platz) {
        platz = platz ? platz * 2 : 256;
        bloecke = realloc(bloecke, sizeof(void *) * platz);
        groessen = realloc(groessen, sizeof(size_t) * platz);
    }
    bloecke[anzahl] = p; groessen[anzahl] = n; anzahl++;
}
/* Groesse des Blocks, wenn er zu diesem Lauf gehoerte (und jetzt vergessen ist), sonst 0 */
static size_t vergessen(void *p) {
    for (long i = anzahl - 1; i >= 0; i--) if (bloecke[i] == p) {
        size_t n = groessen[i];
        anzahl--; bloecke[i] = bloecke[anzahl]; groessen[i] = groessen[anzahl];
        return n;
    }
    return 0;
}

static size_t klasse(size_t n) { size_t k = 64; while (k < n) k *= 2; return k; }
static void freigeben(void *p, size_t n) {
    if (!vorrat_an) { free(p); return; }
    if (vorrat_anzahl == vorrat_platz) {
        vorrat_platz = vorrat_platz ? vorrat_platz * 2 : 256;
        vorrat = realloc(vorrat, sizeof(void *) * vorrat_platz);
        vorrat_groessen = realloc(vorrat_groessen, sizeof(size_t) * vorrat_platz);
    }
    vorrat[vorrat_anzahl] = p; vorrat_groessen[vorrat_anzahl] = n; vorrat_anzahl++;
}
static void *belegen(size_t n, size_t *bekommen) {
    if (!vorrat_an) { *bekommen = n; return malloc(n); }
    size_t k = klasse(n);
    long passend = 0;
    for (long i = 0; i < vorrat_anzahl; i++) if (vorrat_groessen[i] == k) passend++;
    *bekommen = k;
    if (passend == 0) return malloc(k);
    zufall = zufall * 1103515245u + 12345u;
    long wahl = (long)((zufall >> 8) % (unsigned)passend);
    for (long i = 0; i < vorrat_anzahl; i++) if (vorrat_groessen[i] == k && wahl-- == 0) {
        void *p = vorrat[i];
        vorrat_anzahl--; vorrat[i] = vorrat[vorrat_anzahl]; vorrat_groessen[i] = vorrat_groessen[vorrat_anzahl];
        return p;
    }
    return malloc(k);
}

void nec2c_test_adressen_wiederverwenden(int an, unsigned saat) {
    if (!an) { for (long i = 0; i < vorrat_anzahl; i++) free(vorrat[i]); vorrat_anzahl = 0; }
    vorrat_an = an; zufall = saat ? saat : 1;
}

/* Nach einem Lauf gibt die Huelle alle Bloecke frei; globale Zeiger von nec2c (ggrid.ar1..ar3 stehen nicht in Null_Pointers)
   zeigen dann noch auf freigegebenen Speicher. Darum setzt nec2c_ausfuehren() vor jedem Lauf alle globalen Strukturen
   zurueck (globale_zuruecksetzen). Ein Zeiger, der trotzdem nicht zu diesem Lauf gehoert, wird hier nicht freigegeben und
   beim Vergroessern neu belegt. */
void *nec2c_malloc(size_t n) { size_t k; void *p = belegen(n, &k); merken(p, k); return p; }
void *nec2c_realloc(void *p, size_t n) {
    size_t alt = p ? vergessen(p) : 0;
    if (!alt) p = NULL;                     /* veralteter Zeiger aus einem frueheren Lauf: neu belegen */
    if (!vorrat_an) {
        void *q = realloc(p, n);
        if (q) merken(q, n);
        return q;
    }
    if (p && n <= alt) { merken(p, alt); return p; }
    size_t k; void *q = belegen(n, &k);
    if (q && p) memcpy(q, p, alt);
    if (p) freigeben(p, alt);
    merken(q, k);
    return q;
}
void nec2c_free(void *p) { size_t n = p ? vergessen(p) : 0; if (n) freigeben(p, n); }

void nec2c_exit(int status) {
    if (laeuft) { ende_status = status; longjmp(ruecksprung, 1); }
    _exit(status);
}

/* Alle globalen Strukturen von nec2c (shared.c) vor jedem Lauf auf null setzen – so, wie sie in einem frischen Prozess des
   Programms stehen (shared.c hat keine Startwerte). Grund (im Android-Port gefunden, 2026-10-24): ggrid.ar1..ar3 stehen nicht
   in Null_Pointers und zeigen nach einem Lauf auf freigegebenen Speicher. Vergibt der Allokator eine dieser Adressen im
   naechsten Lauf an einen neuen Block, gibt mem_alloc -> free_ptr -> nec2c_free diesen lebenden Block frei: Benutzung nach
   Freigabe, die Sommerfeld-Tabelle wird ueberschrieben (Inverted-V-Nahfeld: Meldungen „ROM2 -- STEP SIZE LIMITED“, Felder
   ~0,5 % daneben). NecBibTests.testSommerfeldMitWiederverwendetenAdressen zeigt es auf dem Mac. */
static void globale_zuruecksetzen(void) {
    memset(&crnt, 0, sizeof crnt); memset(&dataj, 0, sizeof dataj); memset(&data, 0, sizeof data);
    memset(&fpat, 0, sizeof fpat); memset(&ggrid, 0, sizeof ggrid); memset(&gnd, 0, sizeof gnd); memset(&gwav, 0, sizeof gwav);
    memset(&incom, 0, sizeof incom); memset(&matpar, 0, sizeof matpar); memset(&netcx, 0, sizeof netcx); memset(&plot, 0, sizeof plot);
    memset(&save, 0, sizeof save); memset(&segj, 0, sizeof segj); memset(&smat, 0, sizeof smat); memset(&tmi, 0, sizeof tmi);
    memset(&vsorc, 0, sizeof vsorc); memset(&yparm, 0, sizeof yparm); memset(&zload, 0, sizeof zload);
}

int nec2c_ausfuehren(const char *ein, const char *aus) {
    char *argv[] = { "nec2c", "-i", (char *)ein, "-o", (char *)aus, NULL };
    extern int optind, optreset;
    optind = 1; optreset = 1;
    input_fp = output_fp = plot_fp = NULL;
    globale_zuruecksetzen();
    laeuft = 1; ende_status = 0; nec2c_lauf++;
    if (setjmp(ruecksprung) == 0) {
        nec2c_main(5, argv);
        ende_status = 0;
    }
    laeuft = 0;
    if (input_fp) { fclose(input_fp); input_fp = NULL; }
    if (output_fp) { fclose(output_fp); output_fp = NULL; }
    if (plot_fp) { fclose(plot_fp); plot_fp = NULL; }
    for (long i = 0; i < anzahl; i++) freigeben(bloecke[i], groessen[i]);
    anzahl = 0;
    return ende_status;
}

long nec2c_offene_bloecke(void) { return anzahl; }
