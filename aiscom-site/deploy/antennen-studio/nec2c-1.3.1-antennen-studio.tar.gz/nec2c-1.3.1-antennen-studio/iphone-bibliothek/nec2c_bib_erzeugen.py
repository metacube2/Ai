#!/usr/bin/env python3
"""Erzeugt Sources/Nec2cBib aus Kerne/nec2c (nec2c, GPLv3, Neoklis Kyriazis): nec2c als Bibliothek im Prozess der App
(iOS darf keine Hilfsprogramme starten). Aenderungen gegenueber dem Original, alle hier und nur hier:
  1. main() heisst nec2c_main(); Signal-Handler (sigaction) entfallen, die App behaelt ihre eigenen.
  2. exit() → nec2c_exit(): springt per longjmp zurueck in nec2c_ausfuehren() statt den Prozess zu beenden.
  3. malloc/realloc/free in misc.c → nec2c_malloc/realloc/free: jeder Block wird mitgezaehlt und nach dem Lauf freigegeben
     (nec2c gibt bei stop() nichts frei; im eigenen Prozess war das egal, in der App waere es ein Leck je Rechnung).
  4. Dateinamen bis 1000 statt 75 Zeichen (Pfade im Container der App sind lang).
  5. Nach fclose() der Datei-Zeiger auf NULL (die Huelle schliesst nach einem Abbruch offene Dateien).
  6. Zwischenspeicher der Bodeninterpolation (intrp) je Lauf zuruecksetzen.
Von Hand in Sources/Nec2cBib/bib.c (nicht erzeugt):
  7. Vor jedem Lauf alle globalen Strukturen aus shared.c auf null setzen wie in einem frischen Prozess (ggrid.ar1..ar3 fehlen
     in Null_Pointers; ein wieder vergebener Zeiger gab sonst einen lebenden Block frei, Befund Android-Port 2026-10-24).
     Pruefmodus nec2c_test_adressen_wiederverwenden vergibt Adressen wie Androids Allokator (NecBibTests).
Aufruf: python3 werkzeuge/nec2c_bib_erzeugen.py   (danach swift test: NecBibTests vergleicht mit dem Programm)"""
import re, shutil
from pathlib import Path
W = Path(__file__).resolve().parent.parent
Q, Z = W / "Kerne/nec2c", W / "Sources/Nec2cBib"
for f in Z.glob("*"):
    if f.name not in ("bib.c", "include"): f.unlink()
(Z / "include").mkdir(parents=True, exist_ok=True)
for f in list(Q.glob("*.c")) + list(Q.glob("*.h")):
    t = f.read_text(errors="replace")
    t = re.sub(r"\bexit\s*\(", "nec2c_exit(", t)
    # 5. nach fclose den Zeiger zuruecksetzen (sonst schliesst die Huelle nach dem Lauf ein zweites Mal)
    t = re.sub(r"fclose\(\s*(input_fp|output_fp|plot_fp)\s*\);", r"{ fclose( \1 ); \1 = NULL; }", t)
    if f.name == "misc.c":
        t = re.sub(r"\bmalloc\s*\(", "nec2c_malloc(", t)
        t = re.sub(r"\brealloc\s*\(", "nec2c_realloc(", t)
        t = re.sub(r"\bfree\s*\(", "nec2c_free(", t)
    if f.name == "calculations.c":
        # 6. intrp() merkt sich Koeffizienten des letzten Bodenpunkts in statischen Variablen; im Programm beginnt jeder Lauf
        #    frisch, in der Bibliothek erbte der naechste Lauf den vorigen Boden (Inverted-V: Impedanz 0,008 Ohm daneben,
        #    NecBibTests). Zu Beginn jedes Laufs (nec2c_lauf zaehlt hoch) auf die Anfangswerte zuruecksetzen.
        anker = "  complex double fx1, fx2, fx3, fx4;\n"
        assert anker in t and "igrs=-10" in t, "calculations.c/intrp anders als erwartet"
        t = t.replace(anker, anker + "  extern int nec2c_lauf; static int gesehen = -1;\n"
                      "  if( gesehen != nec2c_lauf ) { gesehen = nec2c_lauf; ixs = -10; iys = -10; igrs = -10; ixeg = 0; iyeg = 0;\n"
                      "    dx = 1.; dy = 1.; xs = 0.; ys = 0.; }\n", 1)
    if f.name == "main.c":
        t = t.replace("int main( int argc, char **argv )", "int nec2c_main( int argc, char **argv )")
        t = "\n".join(z for z in t.split("\n") if "sigaction(" not in z)
        t = t.replace('char infile[81] = "", otfile[81] = "";', 'char infile[1024] = "", otfile[1024] = "";')
        t = t.replace("strlen(optarg) > 75", "strlen(optarg) > 1000")
        assert "nec2c_main(" in t and "infile[1024]" in t, "main.c anders als erwartet"
    if f.name == "nec2c.h":
        t = t.replace("#include <stdlib.h>", "#include <stdlib.h>\n/* Nec2cBib: Bibliothek statt Programm (werkzeuge/nec2c_bib_erzeugen.py) */\n"
                      "void nec2c_exit(int status) __attribute__((noreturn));\nvoid *nec2c_malloc(size_t n);\n"
                      "void *nec2c_realloc(void *p, size_t n);\nvoid nec2c_free(void *p);\nint nec2c_main(int argc, char **argv);", 1)
    # main.c heisst nec2c_haupt.c: eine Datei main.c macht das SwiftPM-Ziel zu einem Programm statt einer Bibliothek
    name = "nec2c_haupt.c" if f.name == "main.c" else f.name
    (Z / name).write_text("/* Erzeugt aus Kerne/nec2c durch werkzeuge/nec2c_bib_erzeugen.py – nicht von Hand aendern. GPLv3. */\n" + t)
for f in ["COPYING", "AUTHORS", "README"]:
    if (Q / f).exists(): shutil.copy(Q / f, Z / f"{f}.txt")
print("ok:", sorted(p.name for p in Z.glob("*.c")))
