#!/bin/zsh
# Baut den Rechenkern nec2c (C) als eigenes Programm: Kerne/bin/nec2c (arm64 + x86_64).
# Eigenes Programm statt Bibliothek: Lizenz von nec2c ist uneinheitlich (README Public Domain, COPYING GPL-3);
# als getrennter Prozess bleibt die App davon unberuehrt, und Rechnungen laufen parallel und isoliert.
set -e
cd "${0:A:h}/.."
mkdir -p Kerne/bin
xcrun clang -O2 -w -DHAVE_CONFIG_H -I Kerne/nec2c -arch arm64 -arch x86_64 -mmacosx-version-min=14.0 \
  Kerne/nec2c/*.c -lm -o Kerne/bin/nec2c
echo "Kerne/bin/nec2c gebaut"
